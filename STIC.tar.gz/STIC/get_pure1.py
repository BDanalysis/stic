from __future__ import division
from numpy import *
from operator import itemgetter
import string
import heapq
import sys
import re


with open("get_pure.txt","r") as fn:
	list1=[]
	list2=[]
	list3=[]
	list4=[]
	list5=[]
	list6=[]
	list7=[]
	list8=[]
	list9=[]
	list0=[]
	while (1):
		line=fn.readline()
		an=line.strip().split('\t')
		if not line:
			break
		if float(an[2])<=0.1:
			list1.append(float(an[2]))
		elif float(an[2])>0.1 and float(an[2])<=0.2:
			list2.append(float(an[2]))
		elif float(an[2])>0.2 and float(an[2])<=0.3:
			list3.append(float(an[2]))
		elif float(an[2])>0.3 and float(an[2])<=0.4:
			list4.append(float(an[2]))
		elif float(an[2])>0.4 and float(an[2])<=0.5:
			list5.append(float(an[2]))
		elif float(an[2])>0.5 and float(an[2])<=0.6:
			list6.append(float(an[2]))
		elif float(an[2])>0.6 and float(an[2])<=0.7:
			list7.append(float(an[2]))
		elif float(an[2])>0.7 and float(an[2])<=0.8:
			list8.append(float(an[2]))
		elif float(an[2])>0.8 and float(an[2])<=0.9:
			list9.append(float(an[2]))
		elif float(an[2])>0.9 and float(an[2])<=1:
			list0.append(float(an[2]))
			
	list=[len(list1),len(list2),len(list3),len(list4),len(list5),len(list6),len(list7),len(list8),len(list9),len(list0)]
	Nmax=heapq.nlargest(2,list)
	avg1=0
	avg2=0
	if len(list1)==Nmax[0]:
		for num in list1:
			avg1 += num/Nmax[0]
	if len(list2)==Nmax[0]:
		for num in list2:
			avg1 += num/Nmax[0]
	if len(list3)==Nmax[0]:
		for num in list3:
			avg1 += num/Nmax[0]
	if len(list4)==Nmax[0]:
		for num in list4:
			avg1 += num/Nmax[0]
	if len(list5)==Nmax[0]:
		for num in list5:
			avg1 += num/Nmax[0]
	if len(list6)==Nmax[0]:
		for num in list6:
			avg1 += num/Nmax[0]
	if len(list7)==Nmax[0]:
		for num in list7:
			avg1 += num/Nmax[0]
	if len(list8)==Nmax[0]:
		for num in list8:
			avg1 += num/Nmax[0]
	if len(list9)==Nmax[0]:
		for num in list9:
			avg1 += num/Nmax[0]
	if len(list0)==Nmax[0]:
		for num in list0:
			avg1 += num/Nmax[0]
	
	
	
	if len(list1)==Nmax[1]:
		for num in list1:
			avg2 += num/Nmax[1]
	if len(list2)==Nmax[1]:
		for num in list2:
			avg2 += num/Nmax[1]
	if len(list3)==Nmax[1]:
		for num in list3:
			avg2 += num/Nmax[1]
	if len(list4)==Nmax[1]:
		for num in list4:
			avg2 += num/Nmax[1]
	if len(list5)==Nmax[1]:
		for num in list5:
			avg2 += num/Nmax[1]
	if len(list6)==Nmax[1]:
		for num in list6:
			avg2 += num/Nmax[1]
	if len(list7)==Nmax[1]:
		for num in list7:
			avg2 += num/Nmax[1]
	if len(list8)==Nmax[1]:
		for num in list8:
			avg2 += num/Nmax[1]
	if len(list9)==Nmax[1]:
		for num in list9:
			avg2 += num/Nmax[1]
	if len(list0)==Nmax[1]:
		for num in list0:
			avg2 += num/Nmax[1]
			
			
	if avg1>avg2:
		pure=(avg1+avg2*2)/2
	else:
		pure=(avg1*2+avg2)/2
	
	print("#########################################")
	print("#########################################")
	print("#########################################")
	print("pure=",pure)
		
		
   


