import sys
import os

with open("delete_single.txt","w") as outfile:
	with open ("delete_single.pileup","r") as fn:
		with open("result.txt","r") as fr:
			line = fn.readline()
			linet=fr.readline()
			an=line.strip().split('\t')
			at=linet.strip().split('\t')
			print(len(an[4]))
			for i in range(3):
				print (i)
			print(at[1])
			while 1:
				if int(an[1])==int(at[1]):
					count=0
					if int(an[3])==0:
						line = fn.readline()
						if not line:
							break
						an=line.strip().split('\t')
						linet=fr.readline()
						if not linet:
							break

						at=linet.strip().split('\t')
					else:
						for i in range(len(an[4])):
							if an[4][i]=='A' or an[4][i]=='G' or an[4][i]=='C' or an[4][i]=='T' or an[4][i]=='a' or an[4][i]=='g' or an[4][i]=='c' or an[4][i]=='t':
								count +=1
						outfile.write(str(at[0])+'\t')
						outfile.write(str(at[1])+'\t')
						outfile.write(str(count/(int(an[3])))+'\t')
						outfile.write("\n")
						#print(an[1])
						#print(at[1])
						line = fn.readline()
						if not line:
							break
						an=line.strip().split('\t')

						linet=fr.readline()
						if not linet:
							break

						at=linet.strip().split('\t')
				elif int(an[1])>int(at[1]):
					linet=fr.readline()
					if not linet:
						break
					at=linet.strip().split('\t')
				else:
					line = fn.readline()
					if not line:
						break
					an=line.strip().split('\t')
