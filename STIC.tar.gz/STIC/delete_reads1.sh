#!/bin/bash


    samtools view -h delete_single.sort.bam > delete_single.sort.sam
    python delete_reads.py
    samtools view -bS delete_reads.sam > delete_reads.bam
    samtools sort -n delete_reads.bam delete_reads.sort
    samtools view -h delete_reads.sort.bam > delete_reads.sort.sam
    python delete_single.py
    samtools view -bS delete_single.sam > delete_single.bam
    samtools sort delete_single.bam delete_single.sort
    samtools mpileup -f chr21.fa delete_single.sort.bam > delete_single.pileup



