#!/usr/bin/python
from __future__ import division
import numpy as np
from operator import itemgetter
import string
import sys
import re

	
def Deal_pileup(filename_n):
    outfile=open("tumor_1.txt",'w')
    
    with open(filename_n) as fr:
        for line in fr:
            info=line.strip().split('\t')
            
            if len(info)<5:
                continue
            chrs=info[0]       ###chr	
            pos=info[1] 			###pos		
            ref=info[2]			###ref		
            depth=float(info[3])	###depth
            base=info[4]			###base 
            quality=info[5]			###quality

            lists=[0.0]
            lists=lists*19

            outfile.write(chrs[3:len(chrs)+1])             ###chr
            outfile.write('\t')
            outfile.write(pos)				####pos
            outfile.write('\t')

            lists[0]=depth			
            j=0
            base=re.sub(r'\d[A-Z,a-z]+',"",base)
            for i in range(len(base)):			
                if base[i].isdigit():
                    continue	
                elif base[i-1].isdigit():
                    continue
                elif base[i-1]=="^":
                    continue
                elif base[i]=='.':
                    lists[1]=lists[1]+1
                    lists[9]=lists[9]+ord(quality[j])
                    j=j+1
                elif base[i]==',':
                    lists[2]=lists[2]+1
                    lists[10]=lists[10]+ord(quality[j])
                    j=j+1
                elif base[i]=='A' or base[i]=='C' or base[i]=='T' or base[i]=='N' or base[i]=='G':
                    lists[3]=lists[3]+1
                    lists[11]=lists[11]+ord(quality[j])
                    j=j+1
                elif base[i]=='a' or base[i]=='c' or base[i]=='t' or base[i]=='n' or base[i]=='g':
                    lists[4]=lists[4]+1
                    
                    lists[12]=lists[12]+ord(quality[j])
                    j=j+1
                else:
                    continue				
            if lists[0]!=0:
                lists[5]=lists[1]/lists[0]
                lists[6]=lists[2]/lists[0]
                lists[7]=lists[3]/lists[0]
                lists[8]=lists[4]/lists[0]
                lists[13]=lists[5]*lists[9]
                lists[14]=lists[6]*lists[10]
                lists[15]=lists[7]*lists[11]
                lists[16]=lists[8]*lists[12]
                lists[17]=lists[13]+lists[15]
                lists[18]=lists[17]/lists[0]
                

            for i in range(0,19):
                outfile.write(str(lists[i]))
                outfile.write('\t')
            outfile.write("\n")
        outfile.close()

Deal_pileup("tumor_1.pileup")

