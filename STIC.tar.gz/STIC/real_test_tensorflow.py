import tensorflow as tf
import numpy as np

tf.reset_default_graph()

np.set_printoptions(suppress=True)


batch_size=128

w1=tf.Variable(tf.random_normal([19,64],stddev=1,seed=1,name='w1'))
b1 = tf.Variable(tf.constant(0.1, shape = [64]),name = "b1")
w2=tf.Variable(tf.random_normal([64,10],stddev=1,seed=1,name='w2'))
b2 = tf.Variable(tf.constant(0.1, shape = [10]),name = "b2")
w3=tf.Variable(tf.random_normal([10,1],stddev=1,seed=1,name='w3'))
b3 = tf.Variable(tf.constant(0.1, shape = [1]),name = "b3")

x=tf.placeholder(tf.float32,shape=(None,19),name='x-input')
y_=tf.placeholder(tf.float32,shape=(None,1),name='y-input')

a1 = tf.nn.relu(tf.matmul(x, w1) + b1)
a2 = tf.nn.relu(tf.matmul(a1, w2) + b2)
y=tf.sigmoid(tf.matmul(a2, w3) + b3)

cross_entropy = -tf.reduce_mean(y_*tf.log(tf.clip_by_value(y,1e-10,1.0))+(1-y_)*tf.log(tf.clip_by_value(1-y,1e-10,1.0)))
train_step = tf.train.AdamOptimizer(0.001).minimize(cross_entropy)
correct_prediction = tf.equal(y_, y)
acc = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))


saver = tf.train.Saver()


with tf.Session() as sess:
    ARRAYSIZE=100000
    saver.restore(sess,tf.train.latest_checkpoint('save_my_train'))
    with open("result.txt",'w') as outfile:
        with open('tumor_1.txt','r') as fr:
            TP=0
            FP=0
            FN=0
            TN=0
            mat=np.array([[0 for q in range(41)]for p in range(ARRAYSIZE)],dtype=float)
            for k in range(150):
                #处理数据
                for i in range(ARRAYSIZE):
                    lines=fr.readline()
                    if not lines:
                        break
                    line=lines.strip().split('\t')
                    for j in range(0,len(line)):
                        mat[i][j]=float(line[j])

                c=mat[:,2:21]
                #d=mat[:,54]
                e=mat[:,1]
                f=mat[:,2]
                m=mat[:,5]
                n=mat[:,6]

                result = sess.run(y, feed_dict = {x:  c})
                for h in range(ARRAYSIZE):
                    if result[h] == 1:
                        outfile.write(str(21)+'\t')
                        outfile.write(str(int(e[h]))+'\t')
                        outfile.write(str((int(m[h])+int(n[h]))/int(f[h]))+"\n")
                        #print(d[h])
                '''for k in range(ARRAYSIZE):
                    if (d[k]==result[k]):
                        if (d[k]==1):
                            TP+=1
                        else:
                            TN+=1
                    else:
                        if (d[k]==1):
                            FN+=1
                        else:
                            FP+=1
            print("真阳性率："+str(TP/(TP+FN)))
            print("真阴性率："+str(TN/(TN+FP)))'''
