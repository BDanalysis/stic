import sys
import os

with open("get_somatic.txt","w") as outfile:
    with open("delete_single.txt","r") as fn:
        for line in fn:
            an=line.strip().split('\t')
            if float(an[2])<=0.25:
                outfile.write(line)
