from __future__ import division
from numpy import *
from operator import itemgetter
import string
import sys
import re

'''sample = []
cosmic = []
with open ('hg19_cosmic70.txt','r') as fr_c:
    for line in fr_c:
        line = line.strip().split('\t')
        cosmic.append(line)
        if len(cosmic)==135000:
            break
    print(cosmic[1][1])
with open ('result.txt','r') as fr_s:
    for line in fr_s:
        line = line.strip().split('\t')
        sample.append(line)
    print(sample[1][1])

with open ("10.txt",'w') as outfile:
    for i in range (len(sample)):
        for j in range (135000):
            if sample[i][1]==(cosmic[j][1]):
                outfile.write(str(cosmic[j]))
                outfile.write("\n")'''
###################################################上边是乱序  下边是顺序
with open("get_pure.txt",'w') as outfile:
    with open ('result.txt','r') as fn, open ('get_somatic.txt','r') as ft:
        line = fn.readline()
        an=line.strip().split('\t')
        linet= ft.readline()
        at=linet.strip().split('\t')
        print(int(an[1]))
        i=0
        while 1:
            if int(an[1])==int(at[0]):
                for j in range(0,len(an)):
                    outfile.write(str(an[j])+'\t')
                outfile.write("\n")
                line = fn.readline()
                linet= ft.readline()
                #print(an[0]+'====')
                #print(at[0]+'==')
                if not line:
                    break
                if not linet:
                    break
                an=line.strip().split('\t')
                at=linet.strip().split('\t')
            elif int(an[1])>int(at[0]):
                linet = ft.readline()
                if not linet:
                    break
                at=linet.strip().split('\t')
                #print(at[0]+'tttt')
            else:
                line = fn.readline()
                if not line:
                    break
                an=line.strip().split('\t')
                #print(an[0]+'nnnnnn')
   


