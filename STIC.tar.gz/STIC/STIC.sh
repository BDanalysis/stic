#!/bin/bash
bam=$1
fa=$2
source activate tensorflow
samtools sort $bam tumor.sort
samtools mpileup -f $fa tumor.sort.bam > tumor_1.pileup
python getTumor.py
python real_test_tensorflow.py
python seleceAF1.py
bash delete_reads.sh
python getAF.py
python seleceAF2.py
bash delete_reads1.py
python getAF.py
python seleceAF2.py
bash delete_reads1.py
python getAF.py
python get_somatic.py
python get_pure.py
python get_pure1.py










