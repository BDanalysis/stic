import sys
import os

with open("0.75_0.95_result.txt","w") as outfile:
	
	with open("delete_single.txt","r") as fn:	
		with open("tumor_1.pileup","r") as fr:
			linet=fr.readline()
			at=linet.strip().split('\t')
			line = fn.readline()
				
			lines = line.strip().split('\t')
			while 1:
				if int(lines[1])==int(at[1]):
					if float(lines[2])>0.75 and float(lines[2])<=0.95 and float(lines[2])>0 and float(lines[2])<=0.35:
						for i in range (0,len(lines)):
							outfile.write(str(lines[i])+'\t')
						outfile.write(str(at[2])+'\t')
						outfile.write("\n")
					linet=fr.readline()
					line = fn.readline()
					if not linet:
						break
					if not line:
						break
					at=linet.strip().split('\t')
					lines=line.strip().split('\t')
				elif int(lines[1])>int(at[1]):
					linet=fr.readline()
					if not linet:
						break
					at=linet.strip().split('\t')
				else:
					line=fn.readline()
					if not line:
						break
					lines=line.strip().split('\t')
